// NightScope - FUTBIN fetch helper (runs on futbin.com pages).
// FUTBIN's Cloudflare answers the extension's background with 403, but a same-origin fetch from a futbin.com tab goes
// through (it carries the tab's Cloudflare clearance). background.js (fbFetch) sends {type: "nsFbProxy", path} here;
// only the pages Trending "Popular" needs are allowed.
(function () {
  "use strict";
  const ALLOWED = /^\/\d{2}\/(popular|sales\/\d+\/[a-z0-9-]+\?platform=(ps|pc))$/i;
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg || msg.type !== "nsFbProxy") return false;
    const path = String(msg.path || "");
    if (!ALLOWED.test(path)) {
      sendResponse({ status: 0, html: "" });
      return false;
    }
    fetch(path, { credentials: "include", headers: { Accept: "text/html" } })
      .then(async (r) => sendResponse({ status: r.status, html: r.status === 200 ? await r.text() : "" }))
      .catch(() => sendResponse({ status: 0, html: "" }));
    return true;
  });
})();
