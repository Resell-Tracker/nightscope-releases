// NightScope FUTBIN helper: a small Chrome extension with one job.
// The NightScope desktop app cannot read FUTBIN itself (FUTBIN's "verify you are human" check refuses its built-in
// browser), so while the app runs this helper reads the FUTBIN pages the app's Trending "Popular" asks for, in your
// own Chrome, and hands them to the app on this PC (http://127.0.0.1:47827). Nothing else: no EA web app features,
// no account data. Both parts below are copied unchanged from the NightScope addon's background.js.
"use strict";
const FC_VERSION = 27;

// FUTBIN page HTML for Trending "Popular" (path like "/27/popular"). FUTBIN's Cloudflare answers the service worker
// with 403 (user's screenshot 2026-11-01), so after the first refusal pages are fetched through a futbin.com tab
// (js/futbin-proxy.js, same-origin there). Uses an open FUTBIN tab, else opens one in the background and closes it
// after 45 idle seconds (FUTBIN's ad-heavy page cost frames in the web app while it stayed open). -> {status, html, via: "direct" | "tab"}
let fbDirectBlocked = false;
let fbOwnTab = null;
let fbOwnTabTimer = null;
async function fbProxyTab(fresh) {
  const ready = async (id) => {
    for (let i = 0; i < 60; i++) {
      try {
        const t = await chrome.tabs.get(id);
        if (t.status === "complete") return true;
      } catch (err) {
        return false;
      }
      await new Promise((resolve) => setTimeout(resolve, 500));
    }
    return false;
  };
  if (!fresh) {
    if (fbOwnTab != null) {
      try {
        await chrome.tabs.get(fbOwnTab);
        return fbOwnTab;
      } catch (err) {
        fbOwnTab = null;
      }
    }
    const open = await chrome.tabs.query({ url: ["https://www.futbin.com/*", "https://futbin.com/*"], status: "complete" });
    if (open.length) return open[0].id;
  }
  const t = await chrome.tabs.create({ url: `https://www.futbin.com/${FC_VERSION}/popular`, active: false });
  fbOwnTab = t.id;
  await ready(t.id);
  return t.id;
}
async function fbFetch(path) {
  if (!fbDirectBlocked) {
    try {
      const r = await fetch("https://www.futbin.com" + path, {
        headers: { Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8", "Accept-Language": "en-US,en;q=0.9" },
        credentials: "include",
      });
      if (r.status === 200) return { status: 200, html: await r.text(), via: "direct" };
      if (r.status !== 403 && r.status !== 503) return { status: r.status, html: "", via: "direct" };
      fbDirectBlocked = true;
    } catch (err) {
      fbDirectBlocked = true;
    }
  }
  const ask = (tabId) =>
    new Promise((resolve) => {
      chrome.tabs.sendMessage(tabId, { type: "nsFbProxy", path }, (res) => {
        // "Receiving end does not exist": a FUTBIN tab opened before the extension was (re)loaded has no helper
        resolve(chrome.runtime.lastError ? null : res);
      });
    });
  try {
    let res = await ask(await fbProxyTab(false));
    if (!res) res = await ask(await fbProxyTab(true));
    if (fbOwnTab != null) {
      clearTimeout(fbOwnTabTimer);
      const id = fbOwnTab;
      fbOwnTabTimer = setTimeout(() => {
        chrome.tabs.remove(id).catch(() => {});
        if (fbOwnTab === id) fbOwnTab = null;
      }, 45e3);
    }
    return res ? { status: res.status, html: res.html || "", via: "tab" } : { status: 0, html: "", via: "tab" };
  } catch (err) {
    return { status: 0, html: "", via: "tab" };
  }
}

// ---------- NightScope Backend app bridge ----------
// The desktop app (NightScope Backend) cannot read FUTBIN itself: FUTBIN's "verify you are human" check refuses its
// built-in browser. So while the app runs, this background asks it for work and reads the FUTBIN pages its Trending
// "Popular" needs with fbFetch above, the same way Popular works here. The app holds each "next" request up to 20 s;
// every answer keeps this background awake, and the alarm starts the loop again after a sleep or once the app is opened.
// Only the pages js/futbin-proxy.js allows are read. Not started inside the app itself (it runs a copy of this file).
const NSB_BRIDGE = "http://127.0.0.1:47827/fb-bridge";
const NSB_ALLOWED = /^\/\d{2}\/(popular|sales\/\d+\/[a-z0-9-]+\?platform=(ps|pc))$/i;
let nsbBridgeOn = false;
async function nsbBridgeLoop() {
  if (nsbBridgeOn) return;
  nsbBridgeOn = true;
  try {
    for (;;) {
      let job = null;
      try {
        const r = await fetch(NSB_BRIDGE + "/next", { headers: { "X-NightScope": "fb-bridge" }, cache: "no-store" });
        if (r.status !== 200) break;
        job = (await r.json()).job || null;
      } catch (err) {
        break; // the app is not running
      }
      if (!job) continue;
      let out = { status: 0, html: "" };
      try {
        if (NSB_ALLOWED.test(String(job.path || ""))) out = await fbFetch(String(job.path));
      } catch (err) {}
      try {
        await fetch(NSB_BRIDGE + "/done", {
          method: "POST",
          headers: { "X-NightScope": "fb-bridge", "Content-Type": "application/json" },
          body: JSON.stringify({ id: job.id, status: out.status || 0, html: out.html || "" }),
        });
      } catch (err) {
        break;
      }
    }
  } finally {
    nsbBridgeOn = false;
  }
}
if (chrome.runtime.id !== "nightscope-backend-app" && chrome.alarms) {
  chrome.alarms.create("nsbBridge", { periodInMinutes: 0.5 });
  chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === "nsbBridge") nsbBridgeLoop();
  });
  nsbBridgeLoop();
}
